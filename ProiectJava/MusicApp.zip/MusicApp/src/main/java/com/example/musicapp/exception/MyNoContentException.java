package com.example.musicapp.exception;

public class MyNoContentException extends RuntimeException {

    public MyNoContentException(String message) {

        super(message);

    }

}
