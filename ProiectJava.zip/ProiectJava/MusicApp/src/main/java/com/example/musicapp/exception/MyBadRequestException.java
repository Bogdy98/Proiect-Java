package com.example.musicapp.exception;

public class MyBadRequestException extends RuntimeException {

    public MyBadRequestException(String message) {

        super(message);

    }

}
